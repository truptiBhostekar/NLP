Python 3.9.2 (tags/v3.9.2:1a79785, Feb 19 2021, 13:44:55) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:\Users\manap\AppData\Local\Programs\Python\Python39\texttospeech.py
Traceback (most recent call last):
  File "C:\Users\manap\AppData\Local\Programs\Python\Python39\texttospeech.py", line 3, in <module>
    f = open('file.txt')
FileNotFoundError: [Errno 2] No such file or directory: 'file.txt'
>>> 